import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  // Keeps track of the player's score
  const [score, setScore] = useState(0);

  // Keeps track of how much time is left in the game (starting from 30 seconds)
  const [timeLeft, setTimeLeft] = useState(30);

  // Stores the current position (top and left) of the circle on the screen
  const [position, setPosition] = useState({ top: '50%', left: '50%' });

  // Boolean flag to determine if the game is active or over
  const [isGameActive, setIsGameActive] = useState(false);

  // Runs every time 'isGameActive' or 'timeLeft' changes
  useEffect(() => {
    let timer;

    // If the game is active and there is time left, start the countdown
    if (isGameActive && timeLeft > 0) {
      timer = setInterval(() => {
        // Reduce the time left by 1 second
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } 
    // If time runs out, stop the game
    else if (timeLeft === 0) {
      setIsGameActive(false);
    }

    // Cleanup: clear the interval when the component updates or unmounts
    return () => clearInterval(timer);
  }, [isGameActive, timeLeft]);

  // Starts the game: resets score, time, and positions the first circle
  const startGame = () => {
    setScore(0);
    setTimeLeft(30);
    setIsGameActive(true);
    randomizePosition();  // Place the circle randomly on the screen
  };

  // Randomizes the circle's position within 10%-90% of the screen space
  const randomizePosition = () => {
    const top = Math.floor(Math.random() * 80) + 10;   // 10% to 90% vertically
    const left = Math.floor(Math.random() * 80) + 10;  // 10% to 90% horizontally
    setPosition({ top: `${top}%`, left: `${left}%` });
  };

  // Handles when the circle is clicked
  const handleClick = () => {
    if (!isGameActive) return; // Ignore clicks if the game hasn't started

    setScore(prev => prev + 1);  // Add 1 to the score
    randomizePosition();        // Move the circle to a new random spot
  };

  return (
    <div className="game-container">
      <h1>Click The Circle!</h1>
      <p>Time Left: {timeLeft}s</p>
      <p>Score: {score}</p>

      {/* If the game hasn't started, show the Start button */}
      {!isGameActive ? (
        <button onClick={startGame} className="start-button">
          Start Game
        </button>
      ) : (
        // If the game is active, show the circle at its current position
        <div
          className="circle"
          style={{ top: position.top, left: position.left }}
          onClick={handleClick}
        ></div>
      )}
    </div>
  );
}

export default App;

